// BAHR B24 — فحص قراءة فقط. شغّله من جذر المشروع: node b24-check.js
// لا يطبع أي مفتاح؛ يطبع أسماء ومواضع فقط.
const fs = require('fs'), path = require('path');
const files = fs.readdirSync('.').filter(f => /\.(js|html)$/.test(f) && !/^b24-/.test(f) && !/node_modules/.test(f));
const src = {}; files.forEach(f => src[f] = fs.readFileSync(f, 'utf8'));
const grep = (re, max = 12) => { const out = [];
  for (const f of files) src[f].split('\n').forEach((l, i) => { if (re.test(l) && out.length < max) out.push(f + ':' + (i + 1) + '  ' + l.trim().slice(0, 140)); }); return out; };
const sec = (t, a) => { console.log('\n== ' + t); (a.length ? a : ['(لا نتائج)']).forEach(x => console.log(x)); };

console.log('الملفات المفحوصة:', files.length);
sec('1) ملفات B24 موجودة', ['b24-qr-social.js', 'b24_social_links.sql'].map(f => (fs.existsSync(f) ? 'OK  ' : 'مفقود  ') + f));
sec('2) وسم السكربت في index.html', grep(/b24-qr-social\.js/, 3));
sec('3) عميل Supabase (أسماء فقط)', grep(/function sbc\b|(const|let|var)\s+(sb|sbc|supabaseClient|supa)\s*=|createClient\(/, 10).map(x => x.replace(/(eyJ[\w-]+|https:\/\/[\w-]+\.supabase\.co)/g, '[مخفي]')));
sec('4) الجداول المستخدمة في .from(', (() => { const s = new Set(); for (const f of files) for (const m of src[f].matchAll(/\.from\(\s*['"]([\w]+)['"]/g)) s.add(m[1]); return [...s].sort(); })());
sec('5) مسارات الصفحات العامة (#part- / #s- / #ad / #u- / #b-)', grep(/['"`]#(part|s|ad|l|u|b|biz|user|store|p)[-\/]|location\.hash\s*=|hashchange/, 25));
sec('6) تاريخ التسجيل / created_at للملف الشخصي', grep(/created_at/, 15));
sec('7) QR أو مشاركة موجودة سابقاً (لا نكرر)', grep(/qrcode|QRCode|qr[-_ ]?code|navigator\.share|data-qr/i, 15));
sec('8) حقول اجتماعية موجودة', grep(/instagram|tiktok|whatsapp|wa\.me|telegram/i, 15));
console.log('\nتم. أرسل هذا الإخراج كاملاً.');
