/* BAHR B24 — QR الموحد + روابط التواصل + عضو منذ
   ملف مستقل. لا يلمس app.js. يعمل عبر عناصر data-b24-* أو عبر window.B24.
   إعدادات اختيارية قبل تحميل الملف: window.B24_CONFIG = { routes:{...}, getClient:()=>sb, ... } */
(function (root) {
  'use strict';

  var user = root.B24_CONFIG || {};
  var CFG = {
    defaultCountry: '964',
    qrLib: 'https://cdn.jsdelivr.net/npm/qrcode-generator@1.4.4/qrcode.js',
    table: 'b24_social_links',
    maxLinks: 12,
    timeZone: 'Asia/Baghdad',
    baseUrl: null,
    getClient: null,
    getUserId: null
  };
  var k;
  for (k in user) if (k !== 'routes') CFG[k] = user[k];
  // قوالب الروابط العامة. يجب أن تطابق مسارات الموقع الفعلية (يتحقق منها b24-check.js)
  CFG.routes = Object.assign({
    account: '#u-{id}',
    store: '#b-{id}',
    ad: '#ad-{id}',
    part: '#part-{id}',
    service: '#s-{id}'
  }, user.routes || {});

  /* ───────── أدوات الروابط ───────── */
  function clean(s) {
    return String(s == null ? '' : s).replace(/[\u0000-\u001f\u007f\u200e\u200f\u202a-\u202e]/g, '').trim().slice(0, 300);
  }
  function hostOk(host, list) {
    host = host.toLowerCase();
    return list.some(function (h) { return host === h || host.slice(-(h.length + 1)) === '.' + h; });
  }
  function parseHttps(raw) {
    var s = clean(raw), u;
    if (!s || /\s/.test(s)) return null;
    if (/^[a-z][a-z0-9+.-]*:/i.test(s) && !/^https?:\/\//i.test(s)) return null; // javascript:, data: ...
    if (!/^https?:\/\//i.test(s)) s = 'https://' + s;
    try { u = new URL(s); } catch (e) { return null; }
    if (u.protocol === 'http:') u.protocol = 'https:';
    if (u.protocol !== 'https:' || u.username || u.password) return null;
    if (!/^[a-z0-9.-]+\.[a-z]{2,}$/i.test(u.hostname)) return null;
    return u;
  }
  function hasPath(u) { return u.pathname.replace(/\//g, '').length > 0; }
  var HANDLE = /^@?[A-Za-z0-9._]{2,40}$/;

  var PLATFORMS = {
    whatsapp:  { label: 'واتساب',   color: '#25D366', hosts: ['wa.me', 'api.whatsapp.com', 'chat.whatsapp.com', 'whatsapp.com'] },
    instagram: { label: 'إنستغرام', color: '#E1306C', hosts: ['instagram.com'], build: function (h) { return 'https://www.instagram.com/' + h + '/'; } },
    tiktok:    { label: 'تيك توك',  color: '#111111', hosts: ['tiktok.com'], build: function (h) { return 'https://www.tiktok.com/@' + h; } },
    facebook:  { label: 'فيسبوك',   color: '#1877F2', hosts: ['facebook.com', 'fb.com', 'fb.me'], build: function (h) { return 'https://www.facebook.com/' + h; } },
    youtube:   { label: 'يوتيوب',   color: '#FF0000', hosts: ['youtube.com', 'youtu.be'], build: function (h) { return 'https://www.youtube.com/@' + h; } },
    telegram:  { label: 'تيليغرام', color: '#26A5E4', hosts: ['t.me', 'telegram.me'], build: function (h) { return 'https://t.me/' + h; } },
    x:         { label: 'X',        color: '#000000', hosts: ['x.com', 'twitter.com'], build: function (h) { return 'https://x.com/' + h; } },
    email:     { label: 'البريد',   color: '#6B7280' },
    website:   { label: 'الموقع',   color: '#0A6C8F' }
  };

  /* يرجع {ok:true,url,key} أو {ok:false,error} */
  function normalize(platform, raw) {
    var p = PLATFORMS[platform], s = clean(raw), u, h, digits;
    if (!p) return { ok: false, error: 'منصة غير مدعومة' };
    if (!s) return { ok: false, error: 'الرابط فارغ' };

    if (platform === 'email') {
      s = s.replace(/^mailto:/i, '');
      if (!/^[^\s@<>"']+@[^\s@<>"']+\.[A-Za-z]{2,}$/.test(s)) return { ok: false, error: 'بريد إلكتروني غير صالح' };
      return { ok: true, url: 'mailto:' + s, key: 'email:' + s.toLowerCase() };
    }
    if (platform === 'website') {
      u = parseHttps(s);
      if (!u || /^(localhost|127\.|10\.|192\.168\.)/i.test(u.hostname)) return { ok: false, error: 'رابط موقع غير صالح' };
      return done(platform, u);
    }
    if (platform === 'whatsapp' && /^\+?[\d\s\-()]{7,22}$/.test(s)) {
      digits = s.replace(/\D/g, '');
      if (digits.indexOf('00') === 0) digits = digits.slice(2);
      else if (digits.charAt(0) === '0' && CFG.defaultCountry) digits = CFG.defaultCountry + digits.slice(1);
      if (digits.length < 8 || digits.length > 15) return { ok: false, error: 'رقم واتساب غير صالح (استخدم الصيغة الدولية)' };
      return { ok: true, url: 'https://wa.me/' + digits, key: 'whatsapp:' + digits };
    }
    if (p.build && HANDLE.test(s)) {
      h = s.replace(/^@/, '');
      return done(platform, new URL(p.build(h)));
    }
    u = parseHttps(s);
    if (!u || !hostOk(u.hostname, p.hosts)) return { ok: false, error: 'الرابط لا يطابق منصة ' + p.label };
    if (!hasPath(u)) return { ok: false, error: 'الرابط لا يشير إلى حساب محدد' };
    return done(platform, u);
  }
  function done(platform, u) {
    var key = platform + ':' + (u.hostname + u.pathname).toLowerCase().replace(/^www\./, '').replace(/\/+$/, '');
    return { ok: true, url: u.toString(), key: key };
  }

  /* ───────── رابط QR العام ───────── */
  function publicUrl(type, id) {
    var tpl = CFG.routes[type];
    if (!tpl) throw new Error('نوع غير معروف: ' + type);
    id = String(id == null ? '' : id);
    if (!/^[A-Za-z0-9_-]{1,64}$/.test(id)) throw new Error('معرّف غير صالح');
    var base = CFG.baseUrl || (root.location ? root.location.origin + root.location.pathname : '');
    return base + tpl.replace('{id}', encodeURIComponent(id));
  }

  /* ───────── عضو منذ ───────── */
  function memberSince(iso) {
    if (!iso) return null;
    var d = new Date(iso);
    if (isNaN(d.getTime())) return null;
    var parts = new Intl.DateTimeFormat('en-GB', { timeZone: CFG.timeZone, day: '2-digit', month: '2-digit', year: 'numeric' }).formatToParts(d), o = {};
    parts.forEach(function (x) { o[x.type] = x.value; });
    return 'عضو منذ ' + o.day + '/' + o.month + '/' + o.year;
  }

  var API = { config: CFG, platforms: PLATFORMS, normalize: normalize, publicUrl: publicUrl, memberSince: memberSince };
  if (typeof module !== 'undefined' && module.exports) { module.exports = API; }
  if (typeof document === 'undefined') return;

  /* ───────── واجهة المتصفح ───────── */
  var doc = document;
  function el(tag, attrs, kids) {
    var n = doc.createElement(tag), a;
    for (a in (attrs || {})) {
      if (a === 'text') n.textContent = attrs[a];
      else if (a === 'class') n.className = attrs[a];
      else n.setAttribute(a, attrs[a]);
    }
    (kids || []).forEach(function (c) { if (c) n.appendChild(c); });
    return n;
  }
  function toast(msg, bad) {
    var t = el('div', { class: 'b24-toast' + (bad ? ' b24-bad' : ''), text: msg, role: 'status' });
    doc.body.appendChild(t);
    setTimeout(function () { if (t.parentNode) t.parentNode.removeChild(t); }, 2600);
  }
  var css = '.b24-card{direction:rtl;text-align:center;border:1px solid rgba(128,128,128,.3);border-radius:14px;padding:16px;margin:12px auto;max-width:360px;background:var(--card,#fff);color:var(--text,#111);font-family:inherit}' +
    '.b24-qrbox{display:flex;align-items:center;justify-content:center;background:#fff;border-radius:10px;padding:8px;margin:10px auto;width:fit-content}' +
    '.b24-qrbox canvas{width:min(260px,70vw);height:auto;display:block;image-rendering:pixelated}' +
    '.b24-url{font-size:11px;opacity:.65;word-break:break-all;direction:ltr;margin:6px 0}' +
    '.b24-row{display:flex;flex-wrap:wrap;gap:8px;justify-content:center;margin-top:10px}' +
    '.b24-btn{border:0;border-radius:10px;padding:9px 14px;font:inherit;font-size:13px;cursor:pointer;background:var(--brand,#0a6c8f);color:#fff;min-height:40px}' +
    '.b24-btn.b24-sec{background:transparent;color:inherit;border:1px solid rgba(128,128,128,.4)}' +
    '.b24-note{padding:14px;opacity:.8;font-size:14px}' +
    '.b24-soc{direction:rtl;display:flex;flex-wrap:wrap;gap:10px;justify-content:center;margin:10px 0}' +
    '.b24-ic{width:44px;height:44px;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;color:#fff;text-decoration:none}' +
    '.b24-ic svg{width:24px;height:24px;fill:none;stroke:#fff;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}' +
    '.b24-member{font-size:13px;opacity:.75;direction:rtl}' +
    '.b24-mgr{direction:rtl;max-width:520px;margin:12px auto}' +
    '.b24-line{display:flex;flex-wrap:wrap;gap:6px;align-items:center;margin:8px 0}' +
    '.b24-line select,.b24-line input{font:inherit;font-size:14px;padding:9px;border-radius:8px;border:1px solid rgba(128,128,128,.4);background:transparent;color:inherit;min-height:40px}' +
    '.b24-line input{flex:1;min-width:140px;direction:ltr}' +
    '.b24-toast{position:fixed;bottom:80px;left:50%;transform:translateX(-50%);background:#222;color:#fff;padding:10px 16px;border-radius:10px;z-index:99999;font-size:14px;direction:rtl}' +
    '.b24-toast.b24-bad{background:#b3261e}';
  var st = el('style', { text: css }); (doc.head || doc.documentElement).appendChild(st);

  var ICONS = {
    whatsapp: '<path d="M4 20l1.4-4.2A8 8 0 1 1 8.4 18.8z"/><path d="M9 9c0 3 3 6 6 6l1-1.5-2-1-1 .8c-1-.5-1.8-1.3-2.3-2.3l.8-1-1-2z"/>',
    instagram: '<rect x="4" y="4" width="16" height="16" rx="5"/><circle cx="12" cy="12" r="3.6"/><circle cx="16.8" cy="7.2" r=".6"/>',
    tiktok: '<path d="M14 4v10.5a3.5 3.5 0 1 1-3.5-3.5"/><path d="M14 4c.4 2.4 2 4 4.5 4.2"/>',
    facebook: '<path d="M14.5 20v-7h2.4l.4-3h-2.8V8.3c0-.9.3-1.4 1.5-1.4h1.4V4.2A18 18 0 0 0 15 4c-2.2 0-3.7 1.3-3.7 3.8V10H9v3h2.3v7z"/>',
    youtube: '<rect x="3" y="6" width="18" height="12" rx="4"/><path d="M10 9.5v5l4.5-2.5z"/>',
    telegram: '<path d="M20 4L3.5 10.5l5 2 2 6 3-3.8 4.2 3.3z"/><path d="M8.5 12.5L20 4"/>',
    x: '<path d="M5 5l14 14M19 5L5 19"/>',
    email: '<rect x="3" y="5.5" width="18" height="13" rx="2"/><path d="M3.5 7l8.5 6 8.5-6"/>',
    website: '<circle cx="12" cy="12" r="8.5"/><path d="M3.5 12h17M12 3.5c2.5 2.5 2.5 14.5 0 17M12 3.5c-2.5 2.5-2.5 14.5 0 17"/>'
  };
  function icon(platform) {
    var p = PLATFORMS[platform];
    var a = el('a', { class: 'b24-ic', style: 'background:' + p.color, 'aria-label': p.label, title: p.label });
    a.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true">' + ICONS[platform] + '</svg>';
    return a;
  }

  /* مكتبة QR (تُحمَّل عند الحاجة فقط) */
  var libP = null;
  function loadLib() {
    if (root.qrcode) return Promise.resolve(root.qrcode);
    if (libP) return libP;
    libP = new Promise(function (res, rej) {
      var s = el('script', { src: CFG.qrLib });
      s.onload = function () { root.qrcode ? res(root.qrcode) : rej(new Error('qrcode')); };
      s.onerror = function () { libP = null; rej(new Error('تعذر تحميل مكتبة QR')); };
      doc.head.appendChild(s);
    });
    return libP;
  }
  function drawQR(text, size) {
    return loadLib().then(function (qrcode) {
      var q = qrcode(0, 'M'); q.addData(text); q.make();
      var n = q.getModuleCount(), quiet = 4, cell = Math.max(2, Math.floor((size || 512) / (n + quiet * 2)));
      var px = (n + quiet * 2) * cell, c = el('canvas', { width: px, height: px }), g = c.getContext('2d'), r, col;
      g.fillStyle = '#fff'; g.fillRect(0, 0, px, px); g.fillStyle = '#000';
      for (r = 0; r < n; r++) for (col = 0; col < n; col++) if (q.isDark(r, col)) g.fillRect((col + quiet) * cell, (r + quiet) * cell, cell, cell);
      return c;
    });
  }

  function copyText(t) {
    if (root.navigator.clipboard && root.isSecureContext) return root.navigator.clipboard.writeText(t);
    return new Promise(function (res, rej) {
      var ta = el('textarea', { style: 'position:fixed;opacity:0' }); ta.value = t; doc.body.appendChild(ta); ta.select();
      try { doc.execCommand('copy') ? res() : rej(); } catch (e) { rej(e); } doc.body.removeChild(ta);
    });
  }

  /* opts: {type,id,title,published:true|false,status:'active'|'deleted'|'paused'} */
  function mountQR(box, opts) {
    box.innerHTML = '';
    var card = el('div', { class: 'b24-card' });
    box.appendChild(card);
    if (opts.published === false || (opts.status && opts.status !== 'active')) {
      var msg = opts.status === 'deleted' ? 'هذا العنصر محذوف' : opts.status === 'paused' ? 'هذا العنصر متوقف حالياً' : 'العنصر غير منشور، لا يوجد رمز QR له';
      card.appendChild(el('div', { class: 'b24-note', text: msg }));
      return Promise.resolve(null);
    }
    var url;
    try { url = publicUrl(opts.type, opts.id); } catch (e) { card.appendChild(el('div', { class: 'b24-note', text: 'تعذر إنشاء الرابط: ' + e.message })); return Promise.resolve(null); }
    var holder = el('div', { class: 'b24-qrbox', text: 'جارٍ الإنشاء…' });
    if (opts.title) card.appendChild(el('div', { text: String(opts.title).slice(0, 80), style: 'font-weight:600' }));
    card.appendChild(holder);
    card.appendChild(el('div', { class: 'b24-url', text: url }));
    var canvas = null;
    var row = el('div', { class: 'b24-row' });
    var b1 = el('button', { class: 'b24-btn', type: 'button', text: 'حفظ الصورة' });
    var b2 = el('button', { class: 'b24-btn b24-sec', type: 'button', text: 'مشاركة' });
    var b3 = el('button', { class: 'b24-btn b24-sec', type: 'button', text: 'نسخ الرابط' });
    var b4 = el('button', { class: 'b24-btn b24-sec', type: 'button', text: 'طباعة' });
    [b1, b2, b3, b4].forEach(function (b) { row.appendChild(b); });
    card.appendChild(row);
    b1.onclick = function () {
      if (!canvas) return toast('الرمز غير جاهز', true);
      canvas.toBlob(function (blob) {
        if (!blob) return toast('تعذر حفظ الصورة', true);
        var a = el('a', { download: 'bahr-qr-' + opts.type + '-' + opts.id + '.png', href: URL.createObjectURL(blob) });
        doc.body.appendChild(a); a.click(); doc.body.removeChild(a);
        setTimeout(function () { URL.revokeObjectURL(a.href); }, 4000);
      }, 'image/png');
    };
    b2.onclick = function () {
      if (root.navigator.share) root.navigator.share({ title: opts.title || 'البحّار', url: url }).catch(function () {});
      else copyText(url).then(function () { toast('تم نسخ الرابط'); }, function () { toast('تعذر المشاركة', true); });
    };
    b3.onclick = function () { copyText(url).then(function () { toast('تم نسخ الرابط'); }, function () { toast('تعذر النسخ', true); }); };
    b4.onclick = function () {
      if (!canvas) return toast('الرمز غير جاهز', true);
      var w = root.open('', '_blank');
      if (!w) return toast('اسمح بالنوافذ المنبثقة للطباعة', true);
      w.document.write('<html dir="rtl"><body style="text-align:center;font-family:sans-serif"><h3></h3><img style="width:80vmin" src="' + canvas.toDataURL('image/png') + '"><script>onload=function(){print()}<\/script></body></html>');
      w.document.querySelector('h3').textContent = opts.title || '';
      w.document.close();
    };
    return drawQR(url, 512).then(function (c) {
      canvas = c; holder.textContent = ''; holder.appendChild(c); return c;
    }).catch(function (e) {
      holder.textContent = 'تعذر إنشاء الرمز'; toast(e.message || 'تعذر إنشاء الرمز', true);
    });
  }

  /* ───────── Supabase ───────── */
  function client() {
    if (typeof CFG.getClient === 'function') return CFG.getClient();
    var names = ['sb', 'sbc', 'supabaseClient', 'supa', 'db'], i, c;
    for (i = 0; i < names.length; i++) {
      c = root[names[i]];
      if (typeof c === 'function' && !c.from) { try { c = c(); } catch (e) { c = null; } }
      if (c && typeof c.from === 'function') return c;
    }
    return null;
  }
  function currentUserId() {
    var c = client();
    if (typeof CFG.getUserId === 'function') return Promise.resolve(CFG.getUserId());
    if (!c || !c.auth) return Promise.resolve(null);
    return c.auth.getUser().then(function (r) { return r && r.data && r.data.user ? r.data.user.id : null; }, function () { return null; });
  }

  function loadPublicLinks(ownerId) {
    var c = client();
    if (!c) return Promise.reject(new Error('عميل Supabase غير متاح'));
    return c.from(CFG.table).select('id,platform,url,sort').eq('owner_id', ownerId).eq('is_public', true).order('sort', { ascending: true })
      .then(function (r) { if (r.error) throw r.error; return r.data || []; });
  }

  function renderSocial(box, links) {
    box.innerHTML = '';
    var wrap = el('div', { class: 'b24-soc' }), seen = {}, n = 0;
    (links || []).forEach(function (l) {
      var r = normalize(l.platform, l.url);
      if (!r.ok || seen[r.key]) return;
      seen[r.key] = 1; n++;
      var a = icon(l.platform);
      a.href = r.url; a.target = '_blank'; a.rel = 'noopener noreferrer nofollow';
      wrap.appendChild(a);
    });
    if (n) box.appendChild(wrap);
    return n;
  }

  function mountSocial(box, ownerId) {
    return loadPublicLinks(ownerId).then(function (rows) { renderSocial(box, rows); }).catch(function () { box.innerHTML = ''; });
  }

  function mountManager(box, ownerId) {
    box.innerHTML = '';
    var root_ = el('div', { class: 'b24-mgr b24-card' }), list = el('div'), prev = el('div');
    box.appendChild(root_);
    root_.appendChild(el('div', { text: 'روابط التواصل', style: 'font-weight:600' }));
    root_.appendChild(list);
    root_.appendChild(el('div', { text: 'المعاينة للزوار', style: 'font-size:12px;opacity:.7;margin-top:10px' }));
    root_.appendChild(prev);
    var c = client(), rows = [], uid = null;

    function paint() {
      list.innerHTML = '';
      rows.forEach(function (r) { list.appendChild(line(r)); });
      renderSocial(prev, rows.filter(function (r) { return r.id; }));
    }
    function line(r) {
      var sel = el('select'), inp = el('input', { type: 'text', value: r.url || '', inputmode: 'url', placeholder: 'رابط أو رقم أو @اسم_الحساب' });
      Object.keys(PLATFORMS).forEach(function (p) { var o = el('option', { value: p, text: PLATFORMS[p].label }); if (p === r.platform) o.selected = true; sel.appendChild(o); });
      var save = el('button', { class: 'b24-btn', type: 'button', text: 'حفظ' });
      var del = el('button', { class: 'b24-btn b24-sec', type: 'button', text: 'حذف' });
      save.onclick = function () {
        var n = normalize(sel.value, inp.value);
        if (!n.ok) return toast(n.error, true);
        var dup = rows.some(function (o) { return o !== r && o.id && normalize(o.platform, o.url).key === n.key; });
        if (dup) return toast('هذا الرابط مضاف مسبقاً', true);
        var q = r.id ? c.from(CFG.table).update({ platform: sel.value, url: n.url }).eq('id', r.id).eq('owner_id', uid)
                     : c.from(CFG.table).insert({ owner_id: uid, platform: sel.value, url: n.url, is_public: true, sort: rows.length });
        q.select('id,platform,url').single().then(function (res) {
          if (res.error) return toast('تعذر الحفظ', true);
          r.id = res.data.id; r.platform = res.data.platform; r.url = res.data.url; inp.value = r.url; toast('تم الحفظ'); paint();
        });
      };
      del.onclick = function () {
        if (!r.id) { rows.splice(rows.indexOf(r), 1); return paint(); }
        if (!root.confirm('حذف هذا الرابط؟')) return;
        c.from(CFG.table).delete().eq('id', r.id).eq('owner_id', uid).then(function (res) {
          if (res.error) return toast('تعذر الحذف', true);
          rows.splice(rows.indexOf(r), 1); toast('تم الحذف'); paint();
        });
      };
      return el('div', { class: 'b24-line' }, [sel, inp, save, del]);
    }

    if (!c) { root_.appendChild(el('div', { class: 'b24-note', text: 'الخدمة غير متاحة حالياً' })); return Promise.resolve(); }
    return currentUserId().then(function (id) {
      uid = id;
      if (!uid || uid !== ownerId) { list.appendChild(el('div', { class: 'b24-note', text: 'يمكنك تعديل روابط حسابك فقط' })); return; }
      var add = el('button', { class: 'b24-btn b24-sec', type: 'button', text: '+ إضافة رابط' });
      add.onclick = function () {
        if (rows.length >= CFG.maxLinks) return toast('وصلت للحد الأقصى', true);
        rows.push({ platform: 'whatsapp', url: '' }); paint();
      };
      root_.appendChild(add);
      return c.from(CFG.table).select('id,platform,url').eq('owner_id', uid).order('sort', { ascending: true }).then(function (r) {
        if (r.error) throw r.error; rows = r.data || []; paint();
      });
    }).catch(function () { toast('تعذر تحميل الروابط', true); });
  }

  function mountMember(box, iso) {
    var t = memberSince(iso);
    box.textContent = t || '';
    box.classList.add('b24-member');
    if (!t) box.style.display = 'none';
  }

  /* ───────── تركيب تلقائي عبر data-b24-* ───────── */
  function scan() {
    var n;
    doc.querySelectorAll('[data-b24-qr]:not([data-b24-done])').forEach(function (b) {
      b.setAttribute('data-b24-done', '1');
      var p = b.getAttribute('data-b24-qr').split(':');
      mountQR(b, { type: p[0], id: p.slice(1).join(':'), title: b.getAttribute('data-b24-title'),
        published: b.getAttribute('data-b24-published') !== '0', status: b.getAttribute('data-b24-status') || 'active' });
    });
    doc.querySelectorAll('[data-b24-social]:not([data-b24-done])').forEach(function (b) { b.setAttribute('data-b24-done', '1'); mountSocial(b, b.getAttribute('data-b24-social')); });
    doc.querySelectorAll('[data-b24-manage]:not([data-b24-done])').forEach(function (b) { b.setAttribute('data-b24-done', '1'); mountManager(b, b.getAttribute('data-b24-manage')); });
    doc.querySelectorAll('[data-b24-member]:not([data-b24-done])').forEach(function (b) { b.setAttribute('data-b24-done', '1'); mountMember(b, b.getAttribute('data-b24-member')); });
  }
  var timer = null;
  function schedule() { if (timer) return; timer = setTimeout(function () { timer = null; scan(); }, 150); }
  function start() { scan(); new MutationObserver(schedule).observe(doc.body, { childList: true, subtree: true }); }
  if (doc.readyState === 'loading') doc.addEventListener('DOMContentLoaded', start); else start();

  API.mountQR = mountQR; API.mountSocial = mountSocial; API.mountManager = mountManager; API.mountMember = mountMember;
  API.renderSocial = renderSocial; API.drawQR = drawQR; API.scan = scan;
  root.B24 = API;
})(typeof window !== 'undefined' ? window : globalThis);
