-- BAHR B24 — جدول روابط التواصل (للمراجعة، لا يُنفَّذ تلقائياً)
-- لا يعدّل أي جدول أو سياسة موجودة. جدول جديد فقط.

-- السبب: لا يوجد جدول عام للروابط الاجتماعية؛ هذا يخزّنها بصفّ لكل رابط.
create table if not exists public.b24_social_links (
  id         uuid primary key default gen_random_uuid(),
  owner_id   uuid not null references auth.users(id) on delete cascade,
  platform   text not null check (platform in ('whatsapp','instagram','tiktok','facebook','youtube','telegram','x','email','website')),
  url        text not null check (char_length(url) <= 300 and (url ~* '^https://' or url ~* '^mailto:')),
  is_public  boolean not null default true,
  sort       int not null default 0,
  created_at timestamptz not null default now()
);

-- السبب: منع تكرار نفس الرابط لنفس المالك.
create unique index if not exists b24_social_links_uniq on public.b24_social_links (owner_id, lower(url));
create index if not exists b24_social_links_owner on public.b24_social_links (owner_id);

-- السبب: RLS إلزامي حتى لا يعدّل مستخدم روابط غيره.
alter table public.b24_social_links enable row level security;

-- السبب: الزائر يقرأ الروابط المنشورة فقط.
drop policy if exists b24_sl_read_public on public.b24_social_links;
create policy b24_sl_read_public on public.b24_social_links for select using (is_public = true);

-- السبب: المالك يقرأ كل روابطه بما فيها غير المنشورة.
drop policy if exists b24_sl_read_own on public.b24_social_links;
create policy b24_sl_read_own on public.b24_social_links for select using (owner_id = auth.uid());

-- السبب: الكتابة والتعديل والحذف للمالك فقط.
drop policy if exists b24_sl_insert_own on public.b24_social_links;
create policy b24_sl_insert_own on public.b24_social_links for insert with check (owner_id = auth.uid());

drop policy if exists b24_sl_update_own on public.b24_social_links;
create policy b24_sl_update_own on public.b24_social_links for update using (owner_id = auth.uid()) with check (owner_id = auth.uid());

drop policy if exists b24_sl_delete_own on public.b24_social_links;
create policy b24_sl_delete_own on public.b24_social_links for delete using (owner_id = auth.uid());

-- السبب: حد أقصى 12 رابطاً لكل مالك على مستوى القاعدة وليس الواجهة فقط.
create or replace function public.b24_social_limit() returns trigger language plpgsql as $$
begin
  if (select count(*) from public.b24_social_links where owner_id = new.owner_id) >= 12 then
    raise exception 'max 12 links';
  end if;
  return new;
end $$;
drop trigger if exists b24_social_limit_trg on public.b24_social_links;
create trigger b24_social_limit_trg before insert on public.b24_social_links for each row execute function public.b24_social_limit();

-- ملاحظة: لا تُمنح شارة توثيق من هذه الروابط، والجدول لا يتصل بأي منطق توثيق.
