#!/bin/bash
# B24 مرحلة 2: ربط الوحدة بالصفحات. آمن لإعادة التشغيل. لا يطبع مفاتيح.
cd "$(dirname "$0")" || exit 1
[ -f index.html ] || { echo "index.html غير موجود هنا"; exit 1; }
node --check b24-wire.js || exit 1
cp index.html index.html.bak-b24w
if ! grep -q 'b24-wire.js' index.html; then
  if grep -q 'b24-qr-social.js' index.html; then
    sed -i 's#<script src="b24-qr-social.js"></script>#<script src="b24-wire.js"></script>\n&#' index.html
  else
    echo "وسم b24-qr-social.js غير موجود في index.html — توقفت"; exit 1
  fi
fi
echo "--- ترتيب الوسوم:"; grep -n 'b24-' index.html
echo "--- مفاتيح routes في الوحدة:"; grep -n 'routes' b24-qr-social.js | cut -c1-150 | head -6
echo "--- اختبارات:"; node b24-test.js | grep -c PASS
