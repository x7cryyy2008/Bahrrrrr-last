/* B24 — ربط الوحدة بالصفحات (بدون تعديل app.js).
   يُحمَّل قبل b24-qr-social.js. يضبط B24_CONFIG ثم يضيف عناصر data-b24-* في الصفحات،
   والوحدة نفسها تعبّئها. لا يطبع مفاتيح ولا يكتب في القاعدة. */
(function () {
  'use strict';
  if (window.__b24wire) return;
  window.__b24wire = 1;

  /* ---------- 1) الإعدادات ---------- */
  var C = window.B24_CONFIG = window.B24_CONFIG || {};
  C.routes = C.routes || {};
  var R = { account: '#u-', store: '#biz-', ad: '#p-', part: '#part-', service: '#s-' };
  for (var k in R) { if (!C.routes[k]) C.routes[k] = R[k]; }
  if (!C.getClient) {
    C.getClient = function () {
      try { return typeof window.sbc === 'function' ? window.sbc() : null; } catch (e) { return null; }
    };
  }

  /* ---------- 2) أدوات ---------- */
  var hashAt = Date.now(), cache = {}, timer = null;
  function client() { try { return C.getClient(); } catch (e) { return null; } }
  function q(sel, root) { return (root || document).querySelector(sel); }
  function isConn(el) { return el && document.documentElement.contains(el); }

  function first(table, col, id, cols) {
    /* يحاول عدة أسماء أعمدة لمعرفة مالك السجل؛ يرجع null بصمت عند الفشل */
    var key = table + '|' + id + '|' + col;
    if (cache[key] !== undefined) return cache[key];
    var c = client();
    if (!c) return Promise.resolve(null);
    var p = Promise.resolve(c.from(table).select(col).eq('id', id).maybeSingle())
      .then(function (r) { return r && !r.error && r.data ? r.data[col] || null : null; })
      .catch(function () { return null; });
    cache[key] = p;
    return p;
  }
  function owner(table, id, cols) {
    var i = 0;
    function next() {
      if (i >= cols.length) return Promise.resolve(null);
      return first(table, cols[i++], id).then(function (v) { return v || next(); });
    }
    return next();
  }
  function created(uid) {
    var key = 'created|' + uid;
    if (cache[key] !== undefined) return cache[key];
    var c = client();
    if (!c) return Promise.resolve(null);
    var tabs = ['public_profiles', 'profiles'], i = 0;
    function next() {
      if (i >= tabs.length) return Promise.resolve(null);
      return Promise.resolve(c.from(tabs[i++]).select('created_at').eq('id', uid).maybeSingle())
        .then(function (r) { return r && !r.error && r.data && r.data.created_at ? r.data.created_at : next(); })
        .catch(function () { return next(); });
    }
    return (cache[key] = next());
  }
  function pageTitle(host) {
    var t = q('h1', document.body);
    return ((t && t.textContent) || document.title || '').trim().slice(0, 120);
  }

  /* ---------- 3) الأنماط (للصندوق العائم فقط) ---------- */
  function css() {
    if (q('#b24w-css')) return;
    var s = document.createElement('style');
    s.id = 'b24w-css';
    s.textContent =
      '.b24w-dock{position:fixed;inset-inline-end:12px;bottom:78px;z-index:60;max-width:min(92vw,360px);' +
      'background:#fff;color:#0b2447;border:1px solid #c9a24a;border-radius:14px;box-shadow:0 6px 24px rgba(0,0,0,.25);direction:rtl}' +
      '.b24w-dock>summary{cursor:pointer;padding:10px 14px;font-weight:600;list-style:none}' +
      '.b24w-dock>summary::-webkit-details-marker{display:none}' +
      '.b24w-body{padding:6px 12px 12px;max-height:68vh;overflow:auto}' +
      '.b24w-body>*{margin-top:10px}';
    document.head.appendChild(s);
  }

  /* ---------- 4) إدراج العناصر ---------- */
  function mk(attrs, h, tag) {
    var d = document.createElement(tag || 'div');
    for (var a in attrs) d.setAttribute(a, attrs[a]);
    d.setAttribute('data-b24-wire', '1');
    d.setAttribute('data-b24-hash', h);
    return d;
  }
  function has(h, marker) { return !!q('[data-b24-wire][data-b24-hash="' + h + '"][data-b24-mk="' + marker + '"]'); }
  function dock(h) {
    var d = q('details.b24w-dock[data-b24-hash="' + h + '"]');
    if (d) return q('.b24w-body', d);
    css();
    d = mk({ 'class': 'b24w-dock', 'data-b24-mk': 'dock' }, h, 'details');
    var s = document.createElement('summary');
    s.textContent = 'رمز QR والتواصل';
    var b = document.createElement('div');
    b.className = 'b24w-body';
    d.appendChild(s); d.appendChild(b);
    document.body.appendChild(d);
    return b;
  }
  function put(h, marker, attrs, host, where) {
    if (has(h, marker)) return;
    var el = mk(attrs, h);
    el.setAttribute('data-b24-mk', marker);
    if (host && where === 'after' && host.parentNode) host.parentNode.insertBefore(el, host.nextSibling);
    else if (host) host.appendChild(el);
    else dock(h).appendChild(el);
  }
  function lateFallback() { return Date.now() - hashAt > 2500; }

  function addExtras(h, uid) {
    if (!uid) return;
    if (client() && !has(h, 'social')) {
      var host = q('.b24w-dock[data-b24-hash="' + h + '"] .b24w-body') || null;
      put(h, 'social', { 'data-b24-social': uid }, host && isConn(host) ? host : null);
    }
    created(uid).then(function (iso) {
      if (!iso || location.hash !== h || has(h, 'member')) return;
      var host = q('.b24w-dock[data-b24-hash="' + h + '"] .b24w-body') || null;
      var el = mk({ 'data-b24-member': iso }, h, 'span');
      el.setAttribute('data-b24-mk', 'member');
      (host || dock(h)).appendChild(el);
    });
  }

  function sync() {
    timer = null;
    var h = location.hash || '', m;

    /* حذف ما بقي من صفحة سابقة */
    var old = document.querySelectorAll('[data-b24-wire]');
    for (var i = 0; i < old.length; i++) {
      if (old[i].getAttribute('data-b24-hash') !== h) old[i].parentNode && old[i].parentNode.removeChild(old[i]);
    }

    /* إعلان */
    if ((m = /^#p-([\w-]+)$/.exec(h))) {
      var g = q('.g14b');
      if (g || lateFallback()) put(h, 'qr', { 'data-b24-qr': 'ad:' + m[1], 'data-b24-title': pageTitle(g) }, g, 'after');
      else schedule(2600);
      return;
    }
    /* قطعة */
    if ((m = /^#part-([\w-]+)$/.exec(h))) {
      put(h, 'qr', { 'data-b24-qr': 'part:' + m[1], 'data-b24-title': pageTitle() }, null);
      return;
    }
    /* خدمة */
    if ((m = /^#s-([\w-]+)$/.exec(h))) {
      var sd = q('#sd');
      if ((sd && sd.textContent.trim()) || lateFallback()) {
        put(h, 'qr', { 'data-b24-qr': 'service:' + m[1], 'data-b24-title': pageTitle(sd) }, sd && sd.textContent.trim() ? sd : null);
      } else schedule(2600);
      return;
    }
    /* متجر */
    if ((m = /^#biz-([\w-]+)$/.exec(h))) {
      put(h, 'qr', { 'data-b24-qr': 'store:' + m[1], 'data-b24-title': pageTitle() }, null);
      var bid = m[1];
      owner('business_profiles', bid, ['owner_id', 'user_id']).then(function (uid) {
        if (location.hash === h) addExtras(h, uid);
      });
      return;
    }
    /* حساب عام لمستخدم */
    if ((m = /^#u-([0-9a-f-]{36})$/i.exec(h))) {
      put(h, 'qr', { 'data-b24-qr': 'account:' + m[1], 'data-b24-title': pageTitle() }, null);
      addExtras(h, m[1]);
      return;
    }
    /* حسابي: واجهة إدارة روابط التواصل لصاحب الحساب فقط */
    if (h === '#account') {
      var acc = q('#acc'), uid = window.AU && window.AU.user && window.AU.user.id;
      if (acc && uid && acc.textContent.trim()) put(h, 'manage', { 'data-b24-manage': uid }, acc);
    }
  }
  function schedule(ms) {
    if (timer) return;
    timer = setTimeout(sync, ms || 250);
  }

  function start() {
    window.addEventListener('hashchange', function () { hashAt = Date.now(); schedule(150); });
    new MutationObserver(function () { schedule(250); }).observe(document.body, { childList: true, subtree: true });
    schedule(300);
  }
  if (document.body) start(); else document.addEventListener('DOMContentLoaded', start);
})();
